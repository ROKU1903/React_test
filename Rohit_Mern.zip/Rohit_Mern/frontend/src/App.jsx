import React from 'react'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Navbar from './components/Navbar'
import Addcourse from './components/addcourse'
import Showcourse from './components/Showcourse'
import Editcourse from './components/Editcourse'
import Home from './components/Home'
import 'bootstrap/dist/css/bootstrap.min.css'
const App = () => {
  return (
    <>
      <BrowserRouter>
      <Navbar/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/addcourse' element={<Addcourse/>}/>
        <Route path='/:id' element={< Showcourse/>}/>
        <Route path='/editcourse/:id' element={< Editcourse/>}/>
      </Routes>
      </BrowserRouter>
    </>
  )
}

export default App
