import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useNavigate, useParams , NavLink} from 'react-router-dom'

const Showcourse = () => {
    const {id}=useParams()
    const navigate =useNavigate()
    const [course , setcourse] = useState([])

    useEffect(()=>{
        axios.get(`http://localhost:4000/courses/showcourse/${id}`)
        .then((res)=>setcourse(res.data))
        .catch((err)=>console.log(err))
    },[id])

    const handleDelete=() =>{
        axios.delete(`http://localhost:4000/courses/deletecourse/${id}`)
        .then(()=>navigate('/'))
        .catch((err)=>console.log(err))
    }

    return (
    <>
      <div
        className="container"
      >
        <div
            className="row justify-content-center align-items-center g-2"
        >
            <div className="col">
                <div className="card">
                    <img className="card-img-top" src={course.thumbnail} alt="Title" height={100}width={100}/>
                    <div className="card-body">
                        <h4 className="card-title">{course.coursename}</h4>
                        <h2 className="card-text">{course.instructor}</h2>
                        <h2 className="card-text">{course.category}</h2>
                        <h2 className="card-text">{course.duration} days</h2>
                        <h2 className="card-text">{course.level}</h2>
                        < NavLink name="" id="" to="/" role='button'
                                className="btn btn-primary">
                                back
                        </NavLink>
                        < NavLink name="" id="" to={`/editcourse/${course._id}`} role='button'
                                className="btn btn-secondary">
                                edit
                        </NavLink>
                        <button
                            type="button"
                            className="btn btn-danger"
                            onClick={handleDelete}
                        >
                            delete
                        </button>
                        
                    </div>
                </div>
                
            </div>
        </div>
        
      </div>
      
    </>
  )
}

export default Showcourse
