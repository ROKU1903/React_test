import axios from 'axios'
import React, { useEffect, useState } from 'react'
import {NavLink} from 'react-router-dom'
const Home = () => {
    const [course , setcourse] =useState([])

    useEffect(()=>{
        axios.get("http://localhost:4000/courses")
        .then((res)=>{setcourse(res.data)})
        .catch((err)=>console.log(err))
    },[])
 return (
    <>
      <div
        className="container"
      >
        <div
            className="row justify-content-center align-items-center g-2"
        > {
            course.map((course)=>(
            <div className="col">
               
                        <div className="card" key={course._id}>
                            <img className="card-img-top" src={course.thumbnail} alt="Title" height={100}/>
                            <div className="card-body">
                                <h4 className="card-title">{course.coursename}</h4>
                                <h2 className="card-text">{course.instructor}</h2>
                                < NavLink name="" id="" to={`/${course._id}`} role='button'
                                className="btn btn-primary">
                                read more
                                </NavLink>
                            </div>
                        </div>
            </div>
            ))}
        </div>
        
      </div>
      
    </>
  
)
}

export default Home
