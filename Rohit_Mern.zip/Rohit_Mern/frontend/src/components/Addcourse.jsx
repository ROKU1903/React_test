import React, { useState } from 'react'
import axios from 'axios'
import {useNavigate} from 'react-router-dom'

const Addcourse = () => {
    const [course , setcourse] = useState({coursename:'',instructor:'',category:'',duration:'',level:'',thumbnail:''})
    const navigate = useNavigate()

    const handlesubmit =(e)=>{
        e.preventDefault()
        axios.post('http://localhost:4000/courses/addcourse', course)
        .then(()=>navigate('/'))
        .catch((err)=>console.log(err))
    }
  return (
    <div>
      <div
        className="container"
      >
        <div
            className="row justify-content-center align-items-center g-2"
        >
            <div className="col">
                <div className="card">
                    <div className="card-body">
                        <h4 className="card-title text-centre">Add Course</h4>
                        <form onSubmit={handlesubmit}>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,coursename:e.target.value})}
                                />
                                <label for="formId1">coursename</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,instructor:e.target.value})}
                                />
                                <label for="formId1">instructor</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,category:e.target.value})}
                                />
                                <label for="formId1">category</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="number"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,duration:e.target.value})}
                                />
                                <label for="formId1">duration</label>
                            </div>       
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,level:e.target.value})}
                                />
                                <label for="formId1">level</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    onChange={(e)=>setcourse({...course,thumbnail:e.target.value})}
                                />
                                <label for="formId1">thumbnail</label>
                            </div>
                            <button
                                type="submit"
                                className="btn btn-primary"
                            >
                                submit
                            </button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
        
      </div>
      
    </div>
  )
}

export default Addcourse
