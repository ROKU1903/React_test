import axios from 'axios'
import React, { useEffect, useState } from 'react'
import { useParams } from 'react-router-dom'
import {useNavigate} from 'react-router-dom'

const Editcourse = () => {
    const [course , setcourse] = useState({coursename:'',instructor:'',category:'',duration:'',level:'',thumbnail:''})
    const {id} = useParams()
    const navigate = useNavigate()

    useEffect(()=>{
        axios.get(`http://localhost:4000/courses/showcourse/${id}`)
        .then((res)=>setcourse(res.data))
        .catch((err)=>console.log(err))
    },[id])

    const handleEdit = (e)=>{
        e.preventDefault()
        axios.patch(`http://localhost:4000/courses/editcourse/${id}`,course)
        .then(()=>navigate('/'))
        .catch((err)=>console.log(err))
    }

  return (
    <div>
      <div>
      <div
        className="container"
      >
        <div
            className="row justify-content-center align-items-center g-2"
        >
            <div className="col">
                <div className="card">
                    <div className="card-body">
                        <h4 className="card-title text-centre">Edit Course</h4>
                        <form onSubmit={handleEdit}>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.coursename}
                                    onChange={(e)=>setcourse({...course,coursename:e.target.value})}
                                />
                                <label for="formId1">coursename</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.insturtor}
                                    onChange={(e)=>setcourse({...course,instructor:e.target.value})}
                                />
                                <label for="formId1">instructor</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.category}
                                    onChange={(e)=>setcourse({...course,category:e.target.value})}
                                />
                                <label for="formId1">category</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="number"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.duration}
                                    onChange={(e)=>setcourse({...course,duration:e.target.value})}
                                />
                                <label for="formId1">duration</label>
                            </div>       
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.level}
                                    onChange={(e)=>setcourse({...course,level:e.target.value})}
                                />
                                <label for="formId1">level</label>
                            </div>
                            <div className="form-floating mb-3">
                                <input
                                    type="text"
                                    className="form-control"
                                    name="formId1"
                                    id="formId1"
                                    placeholder=""
                                    value={course.thumbnail}
                                    onChange={(e)=>setcourse({...course,thumbnail:e.target.value})}
                                />
                                <label for="formId1">thumbnail</label>
                            </div>
                            <button
                                type="submit"
                                className="btn btn-primary"
                            >
                                submit
                            </button>
                        </form>
                    </div>
                </div>
                
            </div>
        </div>
        
      </div>
      
    </div>

    </div>
  )
}

export default Editcourse
