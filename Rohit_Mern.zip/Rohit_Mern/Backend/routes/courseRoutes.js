const express = require('express');
const {addcourse,editcourse,showcourse,deletecourse,showcourses} = require('../controller/courseController');

const router = express.Router()

router.post("/addcourse",addcourse);
router.get("/",showcourses);
router.get("/showcourse/:id",showcourse);
router.patch("/editcourse/:id",editcourse);
router.delete("/deletecourse/:id",deletecourse);

module.exports = router;