const mongoose = require('mongoose');

const Courseschema = new mongoose.Schema({
    coursename:{
        type:String,
        required:true
    },
    instructor:{
        type:String,
        required:true
    },
    category:{
        type:String,
        required:true
    },
    duration:{
        type:Number,
        min:25,
        required:true
    },
    level:{
        type:String,
        enum:['Beginner' , 'Intermediate' , 'Advanced'],
        required:true
    },
    thumbnail:{
        type:String
    }
},{timestamps:true})

const CourseModel = mongoose.model("course",Courseschema);

module.exports = CourseModel;