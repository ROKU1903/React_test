const express = require('express');
const {connectDB} = require('./db/db');
const router = require('./routes/courseRoutes');

const cors =require('cors');
const app = express();
connectDB();
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({extended:true}));

app.use("/courses",router);

app.listen(4000,()=>{
    console.log("running....");
})
