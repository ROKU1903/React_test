const CourseModel = require('../model/courseModel');

exports.addcourse = async(req,resp)=>{
    const add_c = new CourseModel(req.body)
    const result = await add_c.save();
    resp.json(result)
}

exports.showcourses = async(req,resp)=>{
    const show_c = await CourseModel.find()
    if (show_c != null) {
        resp.json(show_c)
    } else {
        resp.json({'message':'no courses'})
    }
}
exports.showcourse = async(req,resp)=>{
    const show_c = await CourseModel.findById(req.params.id)
    if (show_c != null) {
        resp.json(show_c)
    } else {
        resp.json({message:'not found ...'})
    }
}

exports.editcourse =async(req,resp)=>{
    const edit_c = await CourseModel.findByIdAndUpdate(req.params.id,req.body,{new:true})
    resp.json({message:'course updated...'})
}

exports.deletecourse = async(req,resp)=>{
    const delete_c = await CourseModel.findByIdAndDelete(req.params.id)
    resp.json({message:'course deleted...'})
}
